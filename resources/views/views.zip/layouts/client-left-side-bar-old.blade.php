<style>
    .left-menu-inner .menu-lvl-0 .menu-link, .left-menu-inner .menu-lvl-0 .favourites-link {
            height: 40px !important;
            min-height: 40px !important;
    }
</style>
<div class="left-pane hideForMob">
   <link href="https://gold365.site/assets/css/desktop/maruti9/style.css" rel="stylesheet" media="print" onload="this.media='all'">
<div _ngcontent-wrn-c84="" class="sidebar d-none col-md-12 d-md-block" style="max-width: 100% !important">
  <app-sidebar _ngcontent-wrn-c84="" _nghost-wrn-c82=""
    ><!----><!---->
    <div _ngcontent-wrn-c82="" class="deposit-withdraw-sidebar-title deposit bg-success text-white p-1">
      <a
        _ngcontent-wrn-c82=""
        target="_blank"
        style="color: initial"
        href="https://wa.link/gold365logindemo"
        ><h5 _ngcontent-wrn-c82="" class="d-inline-block m-b-0 text-white">
          <i class="fa-solid fa-piggy-bank text-white"></i> Deposit
        </h5></a
      >
    </div>
    <!---->
    <div _ngcontent-wrn-c82="" class="deposit-withdraw-sidebar-title withdraw bg-danger text-white p-1">
      <a
        _ngcontent-wrn-c82=""
        target="_blank"
        style="color: initial; "
        href="https://wa.link/gold365logindemo"
        ><h5 _ngcontent-wrn-c82="" class="d-inline-block m-b-0 text-white">
         <i class="fa-solid fa-hand-holding-dollar text-white"> </i> Withdraw
        </h5></a
      >
    </div>
    <!---->
    <div
      _ngcontent-wrn-c82=""
      data-bs-toggle="collapse"
      data-bs-target=".casino"
      class="sidebar-title"
    >
      <h5 _ngcontent-wrn-c82="" class="d-inline-block m-b-0">Others</h5>
    </div>
    <nav _ngcontent-wrn-c82="" class="collapse casino show">
      <!---->
      <ul _ngcontent-wrn-c82="">
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900019"
            routerlink="/casino-detail/99995/900019"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> TP 1 DAY </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900025"
            routerlink="/casino-detail/99995/900025"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> 2 Cards TP </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900027"
            routerlink="/casino-detail/99995/900027"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> DT 1 DAY </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900009"
            routerlink="/casino-detail/99995/900009"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> CASINO WAR </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900046"
            routerlink="/casino-detail/99995/900046"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> CENTER CARD </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900014"
            routerlink="/casino-detail/99995/900014"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> HI LOW </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900012"
            routerlink="/casino-detail/99995/900012"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> LOTTERY </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900006"
            routerlink="/casino-detail/99995/900006"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> BACCARAT </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900007"
            routerlink="/casino-detail/99995/900007"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> AMAR AKBAR ANTHONY </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900011"
            routerlink="/casino-detail/99995/900011"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> BOLLYWOOD </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900037"
            routerlink="/casino-detail/99995/900037"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> TRIO </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900021"
            routerlink="/casino-detail/99995/900021"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> LUCKY7 </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900015"
            routerlink="/casino-detail/99995/900015"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> MUFLIS TP </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900075"
            routerlink="/casino-detail/99995/900075"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> ROULETTE </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900010"
            routerlink="/casino-detail/99995/900010"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> WORLI MATKA </span></a
          >
        </li>
        <li _ngcontent-wrn-c82="" class="nav-item">
          <a
            _ngcontent-wrn-c82=""
            href="/casino-detail/99995/900005"
            routerlink="/casino-detail/99995/900005"
            class="nav-link"
            ><span _ngcontent-wrn-c82=""> CRICKET WAR </span></a
          >
        </li>
      </ul>
      <!---->
    </nav>
    <div
      _ngcontent-wrn-c82=""
      data-bs-toggle="collapse"
      data-bs-target=".events"
      aria-controls="events"
      aria-expanded="true"
      role="button"
      class="sidebar-title m-t-5 theme2bg"
    >
      <h5 _ngcontent-wrn-c82="" class="text-white d-inline-block m-b-0">
        All Sports
      </h5>
    </div>
    <div
      _ngcontent-wrn-c82=""
      id="events"
      class="mtree-main collapse events show"
    >
      <div _ngcontent-wrn-c82="" class="ps">
        <nav _ngcontent-wrn-c82="">
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse0"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Cricket</a
                >
              </div>
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse0"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse00"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Indian Premier League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse00"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/28127348"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Indian Premier League</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214375"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Delhi Capitals v Mumbai Indians</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214377"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Lucknow Super Giants v Rajasthan Royals</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217190"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Gujarat Titans v Royal Challengers Bengaluru</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217205"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Chennai Super Kings v Sunrisers Hyderabad</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223373"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Kolkata Knight Riders v Delhi Capitals</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse01"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Others</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse01"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714126615"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮INDIA T10 VS AUSTRALIA T10</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714217073"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮 SOUTH AFRICA T10 v SRI LANKA T10</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714126635"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮NEW ZEALAND T10 VS ENGLAND T10</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714145727"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮LAHORE QALANDARS T10 VS MULTAN SULTANS T10</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714126625"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮SRI LANKA T10 VS BANGLADESH T10</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714145737"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              🎮AFGHANISTAN T10 VS NEW ZEALAND T10</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse02"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      County Championship Division 1</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse02"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224061"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Warwickshire v Nottinghamshire</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224060"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Surrey v Hampshire</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse03"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Rachael Heyhoe Flint Trophy</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse03"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33219680"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sunrisers v The Blaze</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse04"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ICC Womens World T20 Qualifier Matches</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse04"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223549"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Uganda Women v USA Women</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223533"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              United Arab Emirates Women v Zimbabwe Women</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223409"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Scotland Women v Sri Lanka Women</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse05"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      International Twenty20 Matches</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse05"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223618"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Pakistan v New Zealand</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <!---->
              </ul>
              <!----><!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse1"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Football</a
                >
              </div>
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse1"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse10"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      UEFA Europa League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse10"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a _ngcontent-wrn-c82="" href="/game-detail/4610"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              UEFA Europa League</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse11"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      UEFA Champions League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse11"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a _ngcontent-wrn-c82="" href="/game-detail/78601"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              UEFA Champions League</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse12"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      English Premier League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse12"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209302"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              West Ham v Liverpool</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209321"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Wolves v Luton</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209328"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Man Utd v Burnley</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209323"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Newcastle v Sheff Utd</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209335"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Fulham v Crystal Palace</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209318"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Everton v Brentford</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209320"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Aston Villa v Chelsea</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse13"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Italian Serie A</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse13"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192540"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Lecce v AC Monza</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192539"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Juventus v AC Milan</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192534"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Lazio v Verona</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192537"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Inter v Torino</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse14"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Spanish La Liga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse14"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192768"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Las Palmas v Girona</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192643"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Almeria v Getafe</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192623"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Alaves v Celta Vigo</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192652"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Atletico Madrid v Athletic Bilbao</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse15"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Italian Serie B</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse15"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210190"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Brescia v Spezia</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210197"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Modena v Sudtirol</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209656"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Ternana v Ascoli</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210146"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Parma v Lecco</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210191"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Cosenza v SSD Bari</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210192"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sampdoria v Como</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210336"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Cittadella v Feralpisalo</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210331"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Palermo v Reggiana</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse16"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Chinese Super League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse16"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214776"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Shanghai Port FC v Shanghai Shenhua</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse17"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Egyptian Premier</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse17"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217436"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Baladeyet Al-Mahalla v ZED FC</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215474"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              El Gounah v Al Ittihad (EGY)</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse18"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      French Ligue 2</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse18"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218235"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              St Etienne v Caen</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218236"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Paris FC v Angers</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218234"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Annecy v Bastia</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218226"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Laval v Bordeaux</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218241"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Concarneau v Rodez</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218225"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Pau v Guingamp</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218233"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Valenciennes v Grenoble</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218227"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Amiens v ESTAC Troyes</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218526"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              AC Ajaccio v Quevilly Rouen</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse19"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Polish Ekstraklasa</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse19"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33213526"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Gornik Zabrze v LKS Lodz</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33213524"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Slask Wroclaw v Ruch Chorzow</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209999"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Widzew Lodz v Rakow Czestochowa</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse110"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Swedish Superettan</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse110"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33213815"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Landskrona v Utsiktens</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210830"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Orgryte v Osters</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse111"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Turkish Super League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse111"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212643"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Kasimpasa v Samsunspor</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215144"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sivasspor v Konyaspor</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215143"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Fenerbahce v Besiktas</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212639"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Hatayspor v Basaksehir</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse112"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Portuguese Segunda Liga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse112"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33213417"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Maritimo v Feirense</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33213814"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Leixoes v Vilaverdense</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse113"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      German 3 Liga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse113"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209731"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Duisburg v SV Sandhausen</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212129"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Viktoria Koln v Preussen Munster</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217232"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Saarbrucken v Hallescher FC</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212597"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Jahn Regensburg v Dynamo Dresden</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209247"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Dortmund II v Erzgebirge</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211594"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Verl v Waldhof Mannheim</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse114"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      German Bundesliga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse114"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193865"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Freiburg v Wolfsburg</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193870"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Bayern Munich v Eintracht Frankfurt</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193846"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              RB Leipzig v Dortmund</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193869"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Augsburg v Werder Bremen</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193868"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Leverkusen v Stuttgart</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse115"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Scottish Premiership</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse115"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33201063"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              St Johnstone v Hibernian</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33201062"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Livingston v Ross Co</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33201071"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Kilmarnock v Hearts</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33201060"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Aberdeen v Motherwell</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse116"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Belgian First Division A</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse116"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218166"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Yellow-Red Mechelen v Oud-Heverlee Leuven</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33218171"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Standard v Sint Truiden</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse117"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Belgian First Division B</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse117"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217277"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Patro Eisden Maasmechelen v Deinze</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217268"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Zulte-Waregem v Lommel</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse118"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      English Championship</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse118"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209783"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Watford v Sunderland</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209823"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sheff Wed v West Brom</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209833"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Southampton v Stoke</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209776"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Huddersfield v Birmingham</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209806"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Norwich v Swansea</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209784"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Cardiff v Middlesbrough</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209968"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Blackburn v Coventry</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209809"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Bristol City v Rotherham</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209779"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Millwall v Plymouth</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33209800"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Hull v Ipswich</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse119"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Spanish Segunda Division</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse119"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210474"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Leganes v Zaragoza</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212822"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Burgos v Amorebieta</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211827"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Elche v Espanyol</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211833"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sporting Gijon v Villarreal B</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse120"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Portuguese Primeira Liga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse120"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212535"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Casa Pia v Chaves</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210372"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Vizela v Rio Ave</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214426"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Benfica v Braga</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212785"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Guimaraes v Boavista</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse121"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Romanian Liga I</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse121"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217352"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              FC U Craiova 1948 v Universitatea Cluj</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217362"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              FCSB v Farul Constanta</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse122"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Austrian Bundesliga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse122"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211500"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              WSG Wattens v SC Austria Lustenau</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211508"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Wolfsberger AC v FC Blau Weiss Linz</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse123"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Saudi Professional League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse123"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210897"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Al-Akhdoud v Abha</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210896"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Al-Raed (KSA) v Al-Ettifaq</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210894"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Al-Khaleej Saihat v Al Nassr</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse124"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Croatian 1 HNL</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse124"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214867"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Varazdin v Dinamo Zagreb</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33214868"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Hajduk Split v Rudes</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse125"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Uruguayan Primera Division</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse125"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215965"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Rampla Juniors v Deportivo Maldonado</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215977"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Cerro Largo FC v Boston River</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse126"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Polish I Liga</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse126"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33221291"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Stal Rzeszow v Lechia Gdansk</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217851"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              GKS Tychy v Zaglebie Sosnowiec</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse127"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Norwegian Eliteserien</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse127"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33217325"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Rosenborg v Bodo Glimt</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse128"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      UEFA Women's Champions League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse128"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211065"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Chelsea (W) v Barcelona (W)</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse129"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Greek Super League</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse129"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212003"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              NFC Volos v Panserraikos</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210818"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Panaitolikos v Atromitos</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212005"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Kifisias FC v Pas Giannina</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210955"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Asteras Tripolis v OFI</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse130"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      US Major League Soccer</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse130"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33212132"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Austin FC v LA Galaxy</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse131"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Peruvian Primera Division</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse131"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33215333"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sport Boys (Per) v Union Comercio</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse132"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Ecuadorian Serie A</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse132"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210909"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Univ Catolica (Ecu) v Cumbaya FC</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse133"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      German Bundesliga 2</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse133"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33210002"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Schalke 04 v Fortuna Dusseldorf</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211589"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              FC Magdeburg v VfL Osnabruck</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211581"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Wehen Wiesbaden v Greuther Furth</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33211580"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Nurnberg v Karlsruhe</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse134"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      French Ligue 1</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse134"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33192992"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Paris St-G v Le Havre</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33193016"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Metz v Lille</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse135"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Australian A-League Men</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse135"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33200199"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Sydney FC v Perth Glory</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33200213"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Melbourne City v Western United</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <!---->
              </ul>
              <!----><!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse2"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Tennis</a
                >
              </div>
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse2"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse20"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      WTA Madrid 2024</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse20"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224146"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              L Fernandez v O Jabeur</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223929"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Ostapenko v Mar Carle</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223491"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              B Haddad Maia v Emm Navarro</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223517"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Keys v L Samsonova</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223670"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              C Gauff v D Yastremska</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse21"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ATP Rome Challenger</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse21"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33226989"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Alejandro Moro Canas v Stefano Travaglia</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33226986"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Hugo Dellien v Vilius Gaubas</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse22"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ATP Madrid Open</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse22"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33225267"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Alexander Bublik v Roberto Carballes Baena</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223514"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Daniil Medvedev v Matteo Arnaldi</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223589"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Tomas Machac v Ben Shelton</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223550"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Nicolas Jarry v Flavio Cobolli</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224261"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Alex De Minaur v Rafael Nadal</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33225475"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Grigor Dimitrov v Jakub Mensik</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224176"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Pavel Kotov v Jordan Thompson</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223283"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Pedro Cachin v Frances Tiafoe</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224196"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Roberto Bautista Agut v Karen Khachanov</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33223665"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Felix Auger Aliassime v Adrian Mannarino</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33225474"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Cameron Norrie v Joao Fonseca</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33224156"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Miomir Kecmanovic v Casper Ruud</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse23"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ATP Concepcion Challenger</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse23"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33227576"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Gonzalo Bueno v Jose Pereira</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33228168"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Stefanos Sakellaridis v Juan Pablo Ficovich</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse24"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ATP Savannah Challenger</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse24"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33227359"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Alexander Ritschard v Dmitry Popko</a
                            >
                          </div>
                        </li>
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33227588"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Maxime Janvier v Andres Andrade</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse25"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      ATP Shenzhen Challenger</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse25"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/33228436"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              James Duckworth v Lloyd Harris</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <!---->
              </ul>
              <!----><!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse3"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Horse Racing</a
                >
              </div>
              <!---->
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse3"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225615"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Turffontein (RSA) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225615"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Turffontein (RSA) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225615"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Turffontein (RSA) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225615"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Turffontein (RSA) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222713"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Leicester 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222703"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Haydock 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33222721"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Sandown 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226841"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Gulfstream Park (US) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226857"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Woodbine (US) 27th Apr</a
                    >
                  </div>
                </li>
                <!---->
              </ul>
              <!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse4"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Greyhound Racing</a
                >
              </div>
              <!---->
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse4"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226418"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Doncaster 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226458"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Oxford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226418"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Doncaster 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226418"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Doncaster 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33225208"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Cannington (AUS) 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226473"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Crayford 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226508"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Newcastle 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226530"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Swindon 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226545"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Hove 27th Apr</a
                    >
                  </div>
                </li>
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a _ngcontent-wrn-c82="" href="/game-detail/33226545"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="fas fa-caret-right"></i
                      ></span>
                      Hove 27th Apr</a
                    >
                  </div>
                </li>
                <!---->
              </ul>
              <!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse5"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Politics</a
                >
              </div>
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse5"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse50"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Others</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse50"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1704972513"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              LOK SABHA 2024</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <!---->
              </ul>
              <!----><!---->
            </li>
          </ul>
          <ul _ngcontent-wrn-c82="" class="mtree transit bubba">
            <li _ngcontent-wrn-c82="" class="mtree-node item">
              <div _ngcontent-wrn-c82="" class="text-dark">
                <a
                  _ngcontent-wrn-c82=""
                  data-bs-toggle="collapse"
                  href="#collapse6"
                  ><span _ngcontent-wrn-c82=""
                    ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                  ></span>
                  Binary</a
                >
              </div>
              <ul
                _ngcontent-wrn-c82=""
                class="mtree-level-1 collapse"
                id="collapse6"
              >
                <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                  <div _ngcontent-wrn-c82="" class="text-dark">
                    <a
                      _ngcontent-wrn-c82=""
                      data-bs-toggle="collapse"
                      href="#collapse60"
                      ><span _ngcontent-wrn-c82=""
                        ><i _ngcontent-wrn-c82="" class="far fa-plus-square"></i
                        ><i
                          _ngcontent-wrn-c82=""
                          class="far fa-minus-square"
                          style="display: none"
                        ></i
                      ></span>
                      Others</a
                    >
                  </div>
                  <ul
                    _ngcontent-wrn-c82=""
                    class="mtree-level-1 collapse"
                    id="collapse60"
                  >
                    <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                      <ul _ngcontent-wrn-c82="" class="mtree-level-1">
                        <li _ngcontent-wrn-c82="" class="mtree-node text-dark">
                          <div _ngcontent-wrn-c82="" class="text-dark">
                            <a
                              _ngcontent-wrn-c82=""
                              href="/game-detail/1714089600"
                              ><span _ngcontent-wrn-c82=""
                                ><i
                                  _ngcontent-wrn-c82=""
                                  class="fas fa-caret-right"
                                ></i
                              ></span>
                              Binary / 2024-04-26</a
                            >
                          </div>
                        </li>
                        <!---->
                      </ul>
                    </li>
                  </ul>
                </li>
                <!---->
              </ul>
              <!----><!---->
            </li>
          </ul>
          <!---->
        </nav>
      </div>
    </div></app-sidebar
  >
</div>

</div>