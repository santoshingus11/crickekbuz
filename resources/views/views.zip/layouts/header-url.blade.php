  <title>CRICKETSBUZZ</title>
  <!-- End fonts -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <!-- core:css -->
  <link rel="stylesheet" href="{{asset('admin/assets/css/core.css')}}">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="{{asset('admin/assets/css/flatpickr.min.css')}}">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="{{asset('admin/assets/fonts/feather-font/css/iconfont.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/flag-icon.min.css')}}">
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="{{asset('admin/assets/css/style.min.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/user.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/main.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/new.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/all.css')}}">
  <style>
    
  </style>
  <link rel="stylesheet" href="{{asset('admin/assets/css/select2.min.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/responsive.css')}}">
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.22.1/moment.min.js"></script>
  <link rel="stylesheet" href="{{asset('admin/assets/css/daterangepicker.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/admin.css')}}">
  <link rel="stylesheet" href="{{asset('admin/assets/css/dropify.min.css')}}">
  <script type="text/javascript" src="{{asset('admin/assets/css/daterangepicker.js')}}"></script>
  <!-- End layout styles -->
  <link rel="shortcut icon" href="{{asset('admin/assets/img/favicon.png')}}" />

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  

  