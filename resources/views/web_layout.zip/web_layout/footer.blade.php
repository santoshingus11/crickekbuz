<app-footer>
        <footer id="footer">
          <p class="copyrgt text-center"> Please Gamble Responsible । <a target="_blank" href="javascript:void(0)">Terms &amp; Conditions</a> । <a _ngcontent-wcx-c74="" target="_blank" href="http://localhost/app/#/license">License</a> । <a _ngcontent-wcx-c74="" target="_blank" href="http://localhost/app/#/privacy">Privacy Policy</a> । <a _ngcontent-wcx-c74="" data-toggle="modal" data-target="#rulesModal">Rules &amp; Regulations</a> ©
            Copyright 2020. All Rights Reserved. </p>
        </footer>
      </app-footer>