<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="origin-trial" content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">

  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>CrickekBuz</title>
  <!--<base href="/">-->
  <base href=".">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link rel="icon" type="image/x-icon" href="{{asset('/')}}favicon.ico">
  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon"> -->

  <!-- Google Fonts -->
  <style type="text/css">
    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYNNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoadNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYdNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoY9NZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobdNZUSdy4Q.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAgM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLCwM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAwM9QPFUex17.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDAM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAAM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAQM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDwM9QPFUew.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYNNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoadNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYdNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoY9NZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobdNZUSdy4Q.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCkYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCAYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCgYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCcYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCsYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCoYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCQYb9lecyU.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19-7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19a7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1967DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19G7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1927DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19y7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19K7DQk6YvM.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCkYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCAYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCgYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCcYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCsYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCoYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCQYb9lecyU.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
  </style>

  <!-- assets CSS Files -->
  <style>
    :root {
      --blue: #007bff;
      --indigo: #6610f2;
      --purple: #6f42c1;
      --pink: #e83e8c;
      --red: #dc3545;
      --orange: #fd7e14;
      --yellow: #ffc107;
      --green: #28a745;
      --teal: #20c997;
      --cyan: #17a2b8;
      --white: #fff;
      --gray: #6c757d;
      --gray-dark: #343a40;
      --primary: #007bff;
      --secondary: #6c757d;
      --success: #28a745;
      --info: #17a2b8;
      --warning: #ffc107;
      --danger: #dc3545;
      --light: #f8f9fa;
      --dark: #343a40;
      --breakpoint-xs: 0;
      --breakpoint-sm: 576px;
      --breakpoint-md: 768px;
      --breakpoint-lg: 992px;
      --breakpoint-xl: 1200px;
      --font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    }

    *,
    ::after,
    ::before {
      box-sizing: border-box;
    }

    html {
      font-family: sans-serif;
      line-height: 1.15;
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      font-size: 1rem;
      font-weight: 400;
      line-height: 1.5;
      color: #212529;
      text-align: left;
      background-color: #fff;
    }

    @media print {

      *,
      ::after,
      ::before {
        text-shadow: none !important;
        box-shadow: none !important;
      }

      @page {
        size: a3;
      }

      body {
        min-width: 992px !important;
      }
    }
  </style>
  <link href="{{asset('/')}}/assets/bootstrap.min.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  </noscript>
  <link rel="stylesheet" href="{{asset('/')}}/assets/bs-datepicker.css">
  <link href="{{asset('/')}}/assets/card-characters" rel="stylesheet">

  <style>
    @import url('https://fonts.cdnfonts.com/css/card-characters');

    .card-icon {
      font-family: Card Characters;
      width: 24px;
      text-align: right;
      display: inline-block;
    }

    .card-red {
      color: #ff0000;
    }

    .card-black {
      color: #000000;
    }
  </style>



  <!-- Template Main CSS File -->
  <link rel="stylesheet" href="{{asset('/')}}/assets/theme.css" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/theme.css">
  </noscript>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css");

    body {
      font-family: "Roboto Condensed", sans-serif !important;
      color: #272829;
    }

    @media (max-width: 767px) {}
  </style>
  <link href="{{asset('/')}}/assets/style.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/style.css">
  </noscript>
  <link href="{{asset('/')}}/assets/casinos.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/casinos.css">
  </noscript>
  <style>
    @import url("https://use.fontawesome.com/releases/v5.0.10/css/all.css");

    body {
      font-family: 'Roboto Condensed', sans-serif !important;
      color: #272829;
    }
  </style>
  <link href="{{asset('/')}}/assets/login.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/login.css">
  </noscript>
  <script type="text/javascript" async="" src="{{asset('/')}}/assets/recaptcha__en.js.download" crossorigin="anonymous" integrity="sha384-0lJkOVHDy3ItYlCbUoEzThjP3hLhLYfEFPAkVOCxnJpb5K9Fllso+S8TRBILcfPo"></script>
  <script>
    const hosts = [{
        domain: "localhost",
        description: "Bet with the most trusted online betting exchange in India. Get the best odds, instant withdrawals & deposits, 24/7 customer service and refer bonus. Sign up now!",
      },
      {
        domain: "funexch.net",
        description: "Register Now On India's 1st Licensed Online Casino And Sportsbook. Experience 24/7 Customer Service, Auto Deposit/withdrawal, And 1000+ Live Casino Games & Sports Betting Games. Enjoy 6% Bonus On Every Deposit!"
      }

    ];
    const host = hosts?.find((host) => host?.domain === window.location.hostname);
    if (host) {
      const newMetaTag = document.createElement("meta");
      newMetaTag.name = "description";
      newMetaTag.content = host?.description;
      if (document.querySelector("meta[name='description']")) {
        document.querySelector("meta[name='description']").replaceWith(newMetaTag);
      } else {
        document.head.appendChild(newMetaTag);
      }
    }
  </script>

  <script src="{{asset('/')}}/assets/jquery-3.5.1.min.js.download"></script>

  <script src="{{asset('/')}}/assets/jquery.min.js.download"></script>
  <script src="{{asset('/')}}/assets/bootstrap.bundle.min.js.download"></script>
  <script type="text/javascript" src="{{asset('/')}}/assets/jquery.dataTables.min.js.download"></script>
  <script type="text/javascript" src="{{asset('/')}}/assets/dataTables.bootstrap4.min.js.download"></script>
  <style>
    @charset "UTF-8";

    :root {
      --bs-blue: #0d6efd;
      --bs-indigo: #6610f2;
      --bs-purple: #6f42c1;
      --bs-pink: #d63384;
      --bs-red: #dc3545;
      --bs-orange: #fd7e14;
      --bs-yellow: #ffc107;
      --bs-green: #198754;
      --bs-teal: #20c997;
      --bs-cyan: #0dcaf0;
      --bs-black: #000;
      --bs-white: #fff;
      --bs-gray: #6c757d;
      --bs-gray-dark: #343a40;
      --bs-gray-100: #f8f9fa;
      --bs-gray-200: #e9ecef;
      --bs-gray-300: #dee2e6;
      --bs-gray-400: #ced4da;
      --bs-gray-500: #adb5bd;
      --bs-gray-600: #6c757d;
      --bs-gray-700: #495057;
      --bs-gray-800: #343a40;
      --bs-gray-900: #212529;
      --bs-primary: #0d6efd;
      --bs-secondary: #6c757d;
      --bs-success: #198754;
      --bs-info: #0dcaf0;
      --bs-warning: #ffc107;
      --bs-danger: #dc3545;
      --bs-light: #f8f9fa;
      --bs-dark: #212529;
      --bs-primary-rgb: 13, 110, 253;
      --bs-secondary-rgb: 108, 117, 125;
      --bs-success-rgb: 25, 135, 84;
      --bs-info-rgb: 13, 202, 240;
      --bs-warning-rgb: 255, 193, 7;
      --bs-danger-rgb: 220, 53, 69;
      --bs-light-rgb: 248, 249, 250;
      --bs-dark-rgb: 33, 37, 41;
      --bs-white-rgb: 255, 255, 255;
      --bs-black-rgb: 0, 0, 0;
      --bs-body-color-rgb: 33, 37, 41;
      --bs-body-bg-rgb: 255, 255, 255;
      --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      --bs-gradient: linear-gradient(180deg, #ffffff26, #fff0);
      --bs-body-font-family: var(--bs-font-sans-serif);
      --bs-body-font-size: 1rem;
      --bs-body-font-weight: 400;
      --bs-body-line-height: 1.5;
      --bs-body-color: #212529;
      --bs-body-bg: #fff;
      --bs-border-width: 1px;
      --bs-border-style: solid;
      --bs-border-color: #dee2e6;
      --bs-border-color-translucent: rgba(0, 0, 0, .175);
      --bs-border-radius: 0.375rem;
      --bs-border-radius-sm: 0.25rem;
      --bs-border-radius-lg: 0.5rem;
      --bs-border-radius-xl: 1rem;
      --bs-border-radius-2xl: 2rem;
      --bs-border-radius-pill: 50rem;
      --bs-link-color: #0d6efd;
      --bs-link-hover-color: #0a58ca;
      --bs-code-color: #d63384;
      --bs-highlight-bg: #fff3cd;
    }

    *,
    :after,
    :before {
      box-sizing: border-box;
    }

    @media (prefers-reduced-motion:no-preference) {
      :root {
        scroll-behavior: smooth;
      }
    }

    body {
      margin: 0;
      font-family: var(--bs-body-font-family);
      font-size: var(--bs-body-font-size);
      font-weight: var(--bs-body-font-weight);
      line-height: var(--bs-body-line-height);
      color: var(--bs-body-color);
      text-align: var(--bs-body-text-align);
      background-color: var(--bs-body-bg);
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
    }
  </style>
  <link rel="stylesheet" href="{{asset('/')}}/assets/styles.1f3b1d3fc8356a080acf.css" media="all" onload="this.media=&#39;all&#39;"><noscript>
    <link rel="stylesheet" href="styles.1f3b1d3fc8356a080acf.css">
  </noscript>
  <style type="text/css">
    #_copy {
      align-items: center;
      background: #4494d5;
      border-radius: 3px;
      color: #fff;
      cursor: pointer;
      display: flex;
      font-size: 13px;
      height: 30px;
      justify-content: center;
      position: absolute;
      width: 60px;
      z-index: 1000
    }

    #select-tooltip,
    #sfModal,
    .modal-backdrop,
    div[id^=reader-helper] {
      display: none !important
    }

    .modal-open {
      overflow: auto !important
    }

    ._sf_adjust_body {
      padding-right: 0 !important
    }

    .super_copy_btns_div {
      position: fixed;
      width: 154px;
      left: 10px;
      top: 45%;
      background: #e7f1ff;
      border: 2px solid #4595d5;
      font-weight: 600;
      border-radius: 2px;
      font-family: -apple-system, BlinkMacSystemFont, Segoe UI, PingFang SC, Hiragino Sans GB, Microsoft YaHei, Helvetica Neue, Helvetica, Arial, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol;
      z-index: 5000
    }

    .super_copy_btns_logo {
      width: 100%;
      background: #4595d5;
      text-align: center;
      font-size: 12px;
      color: #e7f1ff;
      line-height: 30px;
      height: 30px
    }

    .super_copy_btns_btn {
      display: block;
      width: 128px;
      height: 28px;
      background: #7f5711;
      border-radius: 4px;
      color: #fff;
      font-size: 12px;
      border: 0;
      outline: 0;
      margin: 8px auto;
      font-weight: 700;
      cursor: pointer;
      opacity: .9
    }

    .super_copy_btns_btn:hover {
      opacity: .8
    }

    .super_copy_btns_btn:active {
      opacity: 1
    }
  </style>
  <style></style>
  <style>
    :root {
      --primary: #2d3387;
      --secondary: #092844;
      --third: #2b329bE6;
      --forth: #092844D9;
      --fifth: #fff;
      --heading-text-color: #fff;
      --active-heading-text-color: #fff;
      --bet-btn: #28a745;
      --stake-btn: #092844;
      --login1: #2b329b;
      --login2: #092844
    }
  </style>
  <script src="{{asset('/')}}/assets/api.js.download" async="" defer=""></script>
  <style>
    .text-custom[_ngcontent-wcx-c78] {
      color: #fff
    }

    .loader[_ngcontent-wcx-c78] {
      min-height: 100px;
      position: relative
    }

    #overlay[_ngcontent-wcx-c78] {
      display: flex;
      align-items: center;
      justify-content: center;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 10;
      background-color: #000000e6
    }

    .dots-circle-spinner[_ngcontent-wcx-c78] {
      display: inline-block;
      height: 1em;
      width: 1em;
      line-height: 1;
      vertical-align: middle;
      border-radius: 1em;
      transition: all .15s linear 0s;
      transform: scale(0);
      opacity: 0;
      box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
    }

    .dots-circle-spinner.loading[_ngcontent-wcx-c78] {
      transform: scale(.5);
      opacity: 1;
      animation: dots-circle-rotation 1.5s linear .15s infinite normal forwards running
    }

    @keyframes dots-circle-rotation {
      to {
        box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
      }

      87.5% {
        box-shadow: 2em 0 0 -.4375em, 1.41421356em 1.41421356em 0 -.375em, 0 2em 0 -.3125em, -1.41421356em 1.41421356em 0 -.25em, -2em 0 0 -.1875em, -1.41421356em -1.41421356em 0 -.125em, 0 -2em 0 -.0625em, 1.41421356em -1.41421356em 0 0
      }

      75% {
        box-shadow: 2em 0 0 -.375em, 1.41421356em 1.41421356em 0 -.3125em, 0 2em 0 -.25em, -1.41421356em 1.41421356em 0 -.1875em, -2em 0 0 -.125em, -1.41421356em -1.41421356em 0 -.0625em, 0 -2em 0 0, 1.41421356em -1.41421356em 0 -.4375em
      }

      62.5% {
        box-shadow: 2em 0 0 -.3125em, 1.41421356em 1.41421356em 0 -.25em, 0 2em 0 -.1875em, -1.41421356em 1.41421356em 0 -.125em, -2em 0 0 -.0625em, -1.41421356em -1.41421356em 0 0, 0 -2em 0 -.4375em, 1.41421356em -1.41421356em 0 -.375em
      }

      50% {
        box-shadow: 2em 0 0 -.25em, 1.41421356em 1.41421356em 0 -.1875em, 0 2em 0 -.125em, -1.41421356em 1.41421356em 0 -.0625em, -2em 0 0 0, -1.41421356em -1.41421356em 0 -.4375em, 0 -2em 0 -.375em, 1.41421356em -1.41421356em 0 -.3125em
      }

      37.5% {
        box-shadow: 2em 0 0 -.1875em, 1.41421356em 1.41421356em 0 -.125em, 0 2em 0 -.0625em, -1.41421356em 1.41421356em 0 0, -2em 0 0 -.4375em, -1.41421356em -1.41421356em 0 -.375em, 0 -2em 0 -.3125em, 1.41421356em -1.41421356em 0 -.25em
      }

      25% {
        box-shadow: 2em 0 0 -.125em, 1.41421356em 1.41421356em 0 -.0625em, 0 2em 0 0, -1.41421356em 1.41421356em 0 -.4375em, -2em 0 0 -.375em, -1.41421356em -1.41421356em 0 -.3125em, 0 -2em 0 -.25em, 1.41421356em -1.41421356em 0 -.1875em
      }

      12.5% {
        box-shadow: 2em 0 0 -.0625em, 1.41421356em 1.41421356em 0 0, 0 2em 0 -.4375em, -1.41421356em 1.41421356em 0 -.375em, -2em 0 0 -.3125em, -1.41421356em -1.41421356em 0 -.25em, 0 -2em 0 -.1875em, 1.41421356em -1.41421356em 0 -.125em
      }

      0% {
        box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
      }
    }
  </style>
  <style>
    .flex-grid {
      display: flex;
      text-align: center;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 18px;
      color: #fff;
      padding: 0;
      width: 100%;
      margin: 0
    }

    .flex-child {
      width: 50%;
      text-align: center;
      background-color: #bb1919
    }

    .flex-child:nth-child(2) {
      background-color: #8a1538
    }

    .flex-child__content {
      display: inline-block;
      background-color: initial;
      width: 100%;
      text-align: center
    }

    .top-nav-event {
      background: #1a5684 !important;
      scrollbar-width: 0 !important
    }

    .top-nav-event::webkit-scrollbar {
      width: 0 !important;
      background: #0000 !important;
      display: none !important
    }

    .bg-color {
      background: #101450 !important
    }
  </style>
  <style>
    b {
      font-weight: 400 !important
    }

    .searchAnchor {
      color: #000 !important
    }

    .searchAnchor:hover {
      color: #fff !important
    }

    .game-date,
    .search-game-name {
      float: left;
      width: 50%
    }

    .game-teams {
      width: 100%;
      float: left
    }

    .searchM .search {
      position: absolute;
      margin: auto;
      top: 0;
      right: 0;
      bottom: 0;
      left: 8px;
      width: 30px;
      height: 30px;
      background: #fff;
      border-radius: 50%;
      transition: all 1s;
      z-index: 4;
      text-align: center;
      line-height: 30px
    }

    .searchM .search:hover {
      cursor: pointer
    }

    .searchM input {
      position: absolute;
      margin: auto;
      text-align: left;
      top: 0;
      right: 0;
      bottom: 0;
      left: 8px;
      width: auto;
      height: 30px;
      outline: none;
      border: none;
      background: #fff;
      color: #000;
      border-radius: 30px;
      transition: all 1s;
      opacity: 0;
      z-index: 5;
      font-weight: bolder
    }

    .searchM input:hover {
      cursor: pointer
    }

    .searchM input:focus {
      width: 200px;
      opacity: 1;
      cursor: text
    }

    .searchM input:focus~.search {
      right: -360px;
      background: #fff;
      z-index: 6
    }

    .searchM input:focus~.search:before {
      top: 0;
      left: 0;
      width: 25px
    }

    .searchM input:focus~.search:after {
      top: 0;
      left: 0;
      width: 25px;
      height: 2px;
      border: none;
      background: #fff;
      border-radius: 0;
      transform: rotate(-45deg)
    }

    .searchM input::placeholder {
      color: #000;
      opacity: .5;
      font-weight: bolder
    }
  </style>
  <style>
    .collapse[_ngcontent-wcx-c73] {
      cursor: pointer
    }
  </style>
  <style>
    b {
      font-weight: 400 !important
    }

    .dash_casino h2 {
      display: block;
      padding-left: 10px;
      text-align: left
    }

    .listing_screen h2 {
      background: #0000
    }

    .live-casino-block {
      margin-right: 0;
      width: 100%;
      height: 106px
    }

    .live-casino-img {
      width: 100% !important;
      height: 100px
    }

    .live-casino-title {
      font-size: 9px !important;
      border-radius: 0
    }

    .coupon-card {
      margin-bottom: 16px;
      border-radius: 0 0 2px 2px
    }

    .table-bordered {
      border: 1px solid #dee2e6
    }

    .coupon-table {
      margin-bottom: 0
    }

    .text-dark {
      color: #343a40 !important
    }

    .coupon-table tr td:first-child {
      padding-left: 15px;
      vertical-align: middle;
      padding-right: 15px
    }

    .coupon-table tr td {
      padding: 0;
      vertical-align: middle;
      font-size: 14px;
      word-wrap: break-word
    }

    .horse-time-detail {
      display: flex;
      flex-wrap: wrap;
      padding: 5px 5px 0
    }

    .horse-time-detail a {
      display: flex
    }

    .horse-time-detail span {
      font-size: 12px;
      background: #092844;
      color: #fff;
      padding: 5px 10px;
      border-radius: 4px;
      margin-right: 5px;
      margin-bottom: 5px;
      cursor: pointer;
      position: relative;
      -webkit-border-radius: 4px;
      -moz-border-radius: 4px;
      -ms-border-radius: 4px;
      -o-border-radius: 4px
    }

    .horse-time-detail span.active {
      position: relative
    }

    .horse-time-detail span.active:before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      border-right: 10px solid #0000;
      border-top: 10px solid green
    }

    .bet-table.horse-table .row {
      border: 1px solid #ddd
    }

    .bet-table.horse-table .row .col-12 {
      border-left: 1px solid #ddd
    }

    .casinoicons {
      margin-right: 0;
      margin-bottom: 16px;
      box-shadow: none
    }

    .grid-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
      grid-gap: 6px;
      gap: 6px;
      padding: 0 10px
    }

    .img-fluid {
      border-radius: 4px 4px 0 0
    }

    .game-img {
      width: 100%;
      height: 150px
    }

    .games-name {
      background: #1a5684;
      width: 33.33%;
      padding: 6px;
      color: #fff;
      font-size: 12px;
      text-align: center
    }

    .cursor {
      cursor: pointer
    }

    @media (max-width: 767px) {
      .grid-container {
        grid-template-columns: repeat(auto-fill, minmax(84px, 1fr))
      }

      .bet-table.horse-table .row .col-12 {
        border-left: none
      }

      .game-img {
        height: 100px
      }

      .horse-time-detail span {
        background: #092844;
        color: #fff;
        padding: 4px 6px
      }

      .horse-time-detail {
        padding: 0
      }
    }
  </style>
  <style>
     .nav-tabs .nav-item.disabled a.disabled {
      cursor: default
    }
  </style>
</head>