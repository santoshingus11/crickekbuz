<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta http-equiv="origin-trial"
    content="Az520Inasey3TAyqLyojQa8MnmCALSEU29yQFW8dePZ7xQTvSt73pHazLFTK5f7SyLUJSo2uKLesEtEa9aUYcgMAAACPeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkRpc2FibGVUaGlyZFBhcnR5U3RvcmFnZVBhcnRpdGlvbmluZyIsImV4cGlyeSI6MTcyNTQwNzk5OSwiaXNTdWJkb21haW4iOnRydWUsImlzVGhpcmRQYXJ0eSI6dHJ1ZX0=">

  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>CRICKET247BUZZ</title>
  <!--<base href="/">-->
  <base href=".">
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
  <meta content="" name="description">
  <meta content="" name="keywords">
  <link rel="icon" type="image/x-icon" href="{{url('/')}}/favicon.ico">
  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon"> -->

  <!-- Google Fonts -->
  <style type="text/css">
    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYNNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoadNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYdNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoYtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEoY9NZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDpCEobdNZUSdy4Q.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAgM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLCwM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAwM9QPFUex17.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDAM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAAM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLAQM9QPFUex17.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVj2ZhZI2eCN5jzbjEETS9weq8-19eLDwM9QPFUew.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYNNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoadNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYdNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoYtNZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYoY9NZUSdy4ehI.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: italic;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVg2ZhZI2eCN5jzbjEETS9weq8-19eDtCYobdNZUSdy4Q.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCkYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCAYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCgYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCcYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCsYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCoYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 300;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-33mZGCQYb9lecyU.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19-7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19a7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1967DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19G7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-1927DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19y7DQk6YvNkeg.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 400;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVl2ZhZI2eCN5jzbjEETS9weq8-19K7DQk6YvM.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCkYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCAYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCgYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+1F00-1FFF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCcYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0370-03FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCsYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0102-0103, U+0110-0111, U+0128-0129, U+0168-0169, U+01A0-01A1, U+01AF-01B0, U+1EA0-1EF9, U+20AB;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCoYb9lecyVC4A.woff2) format('woff2');
      unicode-range: U+0100-02AF, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
    }

    @font-face {
      font-family: 'Roboto Condensed';
      font-style: normal;
      font-weight: 700;
      font-display: swap;
      src: url(https://fonts.gstatic.com/s/robotocondensed/v25/ieVi2ZhZI2eCN5jzbjEETS9weq8-32meGCQYb9lecyU.woff2) format('woff2');
      unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
    }
  </style>

  <!-- assets CSS Files -->
  <style>
    :root {
      --blue: #007bff;
      --indigo: #6610f2;
      --purple: #6f42c1;
      --pink: #e83e8c;
      --red: #dc3545;
      --orange: #fd7e14;
      --yellow: #ffc107;
      --green: #28a745;
      --teal: #20c997;
      --cyan: #17a2b8;
      --white: #fff;
      --gray: #6c757d;
      --gray-dark: #343a40;
      --primary: #007bff;
      --secondary: #6c757d;
      --success: #28a745;
      --info: #17a2b8;
      --warning: #ffc107;
      --danger: #dc3545;
      --light: #f8f9fa;
      --dark: #343a40;
      --breakpoint-xs: 0;
      --breakpoint-sm: 576px;
      --breakpoint-md: 768px;
      --breakpoint-lg: 992px;
      --breakpoint-xl: 1200px;
      --font-family-sans-serif: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      --font-family-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
    }

    *,
    ::after,
    ::before {
      box-sizing: border-box;
    }

    html {
      font-family: sans-serif;
      line-height: 1.15;
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
    }

    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      font-size: 1rem;
      font-weight: 400;
      line-height: 1.5;
      color: #212529;
      text-align: left;
      background-color: #fff;
    }

    @media print {

      *,
      ::after,
      ::before {
        text-shadow: none !important;
        box-shadow: none !important;
      }

      @page {
        size: a3;
      }

      body {
        min-width: 992px !important;
      }
    }
  </style>
  <link href="{{asset('/assets/')}}/bootstrap.min.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  </noscript>
  <link rel="stylesheet" href="{{asset('/assets/')}}/bs-datepicker.css">
  <link href="{{asset('/assets/')}}/card-characters" rel="stylesheet">

  <style>
    @import url('https://fonts.cdnfonts.com/css/card-characters');

    .card-icon {
      font-family: Card Characters;
      width: 24px;
      text-align: right;
      display: inline-block;
    }

    .card-red {
      color: #ff0000;
    }

    .card-black {
      color: #000000;
    }
  </style>



  <!-- Template Main CSS File -->
  <link rel="stylesheet" href="{{asset('/assets/')}}/theme.css" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/theme.css">
  </noscript>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css");

    body {
      font-family: "Roboto Condensed", sans-serif !important;
      color: #272829;
    }

    @media (max-width: 767px) {}
  </style>
  <link href="{{asset('/assets/')}}/style.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/style.css">
  </noscript>
  <link href="{{asset('/assets/')}}/casinos.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/casinos.css">
  </noscript>
  <style>
    @import url("https://use.fontawesome.com/releases/v5.0.10/css/all.css");

    body {
      font-family: 'Roboto Condensed', sans-serif !important;
      color: #272829;
    }
  </style>
  <link href="{{asset('/assets/')}}/login.css" rel="stylesheet" media="all" onload="this.media=&#39;all&#39;">
  <noscript>
    <link rel="stylesheet" href="assets/css/login.css">
  </noscript>
  <script type="text/javascript" async="" src="{{asset('/assets/')}}/recaptcha__en.js.download" crossorigin="anonymous"
    integrity="sha384-YaLdSXMqm9CEKTpOkSnpu5vAhzVfmtaskI7GboiAj0dVtvfpzmGU1XBINZ7hs6ET"></script>
  <script>
    const hosts = [
      {
        domain: "localhost",
        description: "Bet with the most trusted online betting exchange in India. Get the best odds, instant withdrawals & deposits, 24/7 customer service and refer bonus. Sign up now!",
      },
      {
        domain: "funexch.net",
        description: "Register Now On India's 1st Licensed Online Casino And Sportsbook. Experience 24/7 Customer Service, Auto Deposit/withdrawal, And 1000+ Live Casino Games & Sports Betting Games. Enjoy 6% Bonus On Every Deposit!"
      }

    ];
    const host = hosts?.find((host) => host?.domain === window.location.hostname);
    if (host) {
      const newMetaTag = document.createElement("meta");
      newMetaTag.name = "description";
      newMetaTag.content = host?.description;
      if (document.querySelector("meta[name='description']")) {
        document.querySelector("meta[name='description']").replaceWith(newMetaTag);
      } else {
        document.head.appendChild(newMetaTag);
      }
    }
  </script>

  <script src="{{asset('/assets/')}}/jquery-3.5.1.min.js.download"></script>

  <script src="{{asset('/assets/')}}/jquery.min(1).js.download"></script>
  <script src="{{asset('/assets/')}}/bootstrap.bundle.min.js.download"></script>
  <script type="text/javascript" src="{{asset('/assets/')}}/jquery.dataTables.min.js.download"></script>
  <script type="text/javascript" src="{{asset('/assets/')}}/dataTables.bootstrap4.min.js.download"></script>
  <style>
    @charset "UTF-8";

    :root {
      --bs-blue: #0d6efd;
      --bs-indigo: #6610f2;
      --bs-purple: #6f42c1;
      --bs-pink: #d63384;
      --bs-red: #dc3545;
      --bs-orange: #fd7e14;
      --bs-yellow: #ffc107;
      --bs-green: #198754;
      --bs-teal: #20c997;
      --bs-cyan: #0dcaf0;
      --bs-black: #000;
      --bs-white: #fff;
      --bs-gray: #6c757d;
      --bs-gray-dark: #343a40;
      --bs-gray-100: #f8f9fa;
      --bs-gray-200: #e9ecef;
      --bs-gray-300: #dee2e6;
      --bs-gray-400: #ced4da;
      --bs-gray-500: #adb5bd;
      --bs-gray-600: #6c757d;
      --bs-gray-700: #495057;
      --bs-gray-800: #343a40;
      --bs-gray-900: #212529;
      --bs-primary: #0d6efd;
      --bs-secondary: #6c757d;
      --bs-success: #198754;
      --bs-info: #0dcaf0;
      --bs-warning: #ffc107;
      --bs-danger: #dc3545;
      --bs-light: #f8f9fa;
      --bs-dark: #212529;
      --bs-primary-rgb: 13, 110, 253;
      --bs-secondary-rgb: 108, 117, 125;
      --bs-success-rgb: 25, 135, 84;
      --bs-info-rgb: 13, 202, 240;
      --bs-warning-rgb: 255, 193, 7;
      --bs-danger-rgb: 220, 53, 69;
      --bs-light-rgb: 248, 249, 250;
      --bs-dark-rgb: 33, 37, 41;
      --bs-white-rgb: 255, 255, 255;
      --bs-black-rgb: 0, 0, 0;
      --bs-body-color-rgb: 33, 37, 41;
      --bs-body-bg-rgb: 255, 255, 255;
      --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
      --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
      --bs-gradient: linear-gradient(180deg, #ffffff26, #fff0);
      --bs-body-font-family: var(--bs-font-sans-serif);
      --bs-body-font-size: 1rem;
      --bs-body-font-weight: 400;
      --bs-body-line-height: 1.5;
      --bs-body-color: #212529;
      --bs-body-bg: #fff;
      --bs-border-width: 1px;
      --bs-border-style: solid;
      --bs-border-color: #dee2e6;
      --bs-border-color-translucent: rgba(0, 0, 0, .175);
      --bs-border-radius: 0.375rem;
      --bs-border-radius-sm: 0.25rem;
      --bs-border-radius-lg: 0.5rem;
      --bs-border-radius-xl: 1rem;
      --bs-border-radius-2xl: 2rem;
      --bs-border-radius-pill: 50rem;
      --bs-link-color: #0d6efd;
      --bs-link-hover-color: #0a58ca;
      --bs-code-color: #d63384;
      --bs-highlight-bg: #fff3cd;
    }

    *,
    :after,
    :before {
      box-sizing: border-box;
    }

    @media (prefers-reduced-motion:no-preference) {
      :root {
        scroll-behavior: smooth;
      }
    }

    body {
      margin: 0;
      font-family: var(--bs-body-font-family);
      font-size: var(--bs-body-font-size);
      font-weight: var(--bs-body-font-weight);
      line-height: var(--bs-body-line-height);
      color: var(--bs-body-color);
      text-align: var(--bs-body-text-align);
      background-color: var(--bs-body-bg);
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
    }
  </style>
  <link rel="stylesheet" href="{{asset('/assets/')}}/styles.1f3b1d3fc8356a080acf.css" media="all"
    onload="this.media=&#39;all&#39;"><noscript>
    <link rel="stylesheet" href="styles.1f3b1d3fc8356a080acf.css">
  </noscript>
  <style></style>
  <style>
    :root {
      --primary: #2d3387;
      --secondary: #092844;
      --third: #2b329bE6;
      --forth: #092844D9;
      --fifth: #fff;
      --heading-text-color: #fff;
      --active-heading-text-color: #fff;
      --bet-btn: #28a745;
      --stake-btn: #092844;
      --login1: #2b329b;
      --login2: #092844
    }
  </style>
  <script src="{{asset('/assets/')}}/api.js.download" async="" defer=""></script>
  <style>
    .text-custom[_ngcontent-vlm-c72] {
      color: #fff
    }

    .loader[_ngcontent-vlm-c72] {
      min-height: 100px;
      position: relative
    }

    #overlay[_ngcontent-vlm-c72] {
      display: flex;
      align-items: center;
      justify-content: center;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 10;
      background-color: #000000e6
    }

    .dots-circle-spinner[_ngcontent-vlm-c72] {
      display: inline-block;
      height: 1em;
      width: 1em;
      line-height: 1;
      vertical-align: middle;
      border-radius: 1em;
      transition: all .15s linear 0s;
      transform: scale(0);
      opacity: 0;
      box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
    }

    .dots-circle-spinner.loading[_ngcontent-vlm-c72] {
      transform: scale(.5);
      opacity: 1;
      animation: dots-circle-rotation 1.5s linear .15s infinite normal forwards running
    }

    @keyframes dots-circle-rotation {
      to {
        box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
      }

      87.5% {
        box-shadow: 2em 0 0 -.4375em, 1.41421356em 1.41421356em 0 -.375em, 0 2em 0 -.3125em, -1.41421356em 1.41421356em 0 -.25em, -2em 0 0 -.1875em, -1.41421356em -1.41421356em 0 -.125em, 0 -2em 0 -.0625em, 1.41421356em -1.41421356em 0 0
      }

      75% {
        box-shadow: 2em 0 0 -.375em, 1.41421356em 1.41421356em 0 -.3125em, 0 2em 0 -.25em, -1.41421356em 1.41421356em 0 -.1875em, -2em 0 0 -.125em, -1.41421356em -1.41421356em 0 -.0625em, 0 -2em 0 0, 1.41421356em -1.41421356em 0 -.4375em
      }

      62.5% {
        box-shadow: 2em 0 0 -.3125em, 1.41421356em 1.41421356em 0 -.25em, 0 2em 0 -.1875em, -1.41421356em 1.41421356em 0 -.125em, -2em 0 0 -.0625em, -1.41421356em -1.41421356em 0 0, 0 -2em 0 -.4375em, 1.41421356em -1.41421356em 0 -.375em
      }

      50% {
        box-shadow: 2em 0 0 -.25em, 1.41421356em 1.41421356em 0 -.1875em, 0 2em 0 -.125em, -1.41421356em 1.41421356em 0 -.0625em, -2em 0 0 0, -1.41421356em -1.41421356em 0 -.4375em, 0 -2em 0 -.375em, 1.41421356em -1.41421356em 0 -.3125em
      }

      37.5% {
        box-shadow: 2em 0 0 -.1875em, 1.41421356em 1.41421356em 0 -.125em, 0 2em 0 -.0625em, -1.41421356em 1.41421356em 0 0, -2em 0 0 -.4375em, -1.41421356em -1.41421356em 0 -.375em, 0 -2em 0 -.3125em, 1.41421356em -1.41421356em 0 -.25em
      }

      25% {
        box-shadow: 2em 0 0 -.125em, 1.41421356em 1.41421356em 0 -.0625em, 0 2em 0 0, -1.41421356em 1.41421356em 0 -.4375em, -2em 0 0 -.375em, -1.41421356em -1.41421356em 0 -.3125em, 0 -2em 0 -.25em, 1.41421356em -1.41421356em 0 -.1875em
      }

      12.5% {
        box-shadow: 2em 0 0 -.0625em, 1.41421356em 1.41421356em 0 0, 0 2em 0 -.4375em, -1.41421356em 1.41421356em 0 -.375em, -2em 0 0 -.3125em, -1.41421356em -1.41421356em 0 -.25em, 0 -2em 0 -.1875em, 1.41421356em -1.41421356em 0 -.125em
      }

      0% {
        box-shadow: 2em 0 0 0, 1.41421356em 1.41421356em 0 -.4375em, 0 2em 0 -.375em, -1.41421356em 1.41421356em 0 -.3125em, -2em 0 0 -.25em, -1.41421356em -1.41421356em 0 -.1875em, 0 -2em 0 -.125em, 1.41421356em -1.41421356em 0 -.0625em
      }
    }
  </style>
  <style>
    .flex-grid {
      display: flex;
      text-align: center;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 18px;
      color: #fff;
      padding: 0;
      width: 100%;
      margin: 0
    }

    .flex-child {
      width: 50%;
      text-align: center;
      background-color: #bb1919
    }

    .flex-child:nth-child(2) {
      background-color: #8a1538
    }

    .flex-child__content {
      display: inline-block;
      background-color: initial;
      width: 100%;
      text-align: center
    }

    .top-nav-event {
      background: #1a5684 !important;
      scrollbar-width: 0 !important
    }

    .top-nav-event::webkit-scrollbar {
      width: 0 !important;
      background: #0000 !important;
      display: none !important
    }

    .bg-color {
      background: #101450 !important
    }
  </style>
  <style>
    b {
      font-weight: 400 !important
    }

    .searchAnchor {
      color: #000 !important
    }

    .searchAnchor:hover {
      color: #fff !important
    }

    .game-date,
    .search-game-name {
      float: left;
      width: 50%
    }

    .game-teams {
      width: 100%;
      float: left
    }

    .searchM .search {
      position: absolute;
      margin: auto;
      top: 0;
      right: 0;
      bottom: 0;
      left: 8px;
      width: 30px;
      height: 30px;
      background: #fff;
      border-radius: 50%;
      transition: all 1s;
      z-index: 4;
      text-align: center;
      line-height: 30px
    }

    .searchM .search:hover {
      cursor: pointer
    }

    .searchM input {
      position: absolute;
      margin: auto;
      text-align: left;
      top: 0;
      right: 0;
      bottom: 0;
      left: 8px;
      width: auto;
      height: 30px;
      outline: none;
      border: none;
      background: #fff;
      color: #000;
      border-radius: 30px;
      transition: all 1s;
      opacity: 0;
      z-index: 5;
      font-weight: bolder
    }

    .searchM input:hover {
      cursor: pointer
    }

    .searchM input:focus {
      width: 200px;
      opacity: 1;
      cursor: text
    }

    .searchM input:focus~.search {
      right: -360px;
      background: #fff;
      z-index: 6
    }

    .searchM input:focus~.search:before {
      top: 0;
      left: 0;
      width: 25px
    }

    .searchM input:focus~.search:after {
      top: 0;
      left: 0;
      width: 25px;
      height: 2px;
      border: none;
      background: #fff;
      border-radius: 0;
      transform: rotate(-45deg)
    }

    .searchM input::placeholder {
      color: #000;
      opacity: .5;
      font-weight: bolder
    }
  </style>
  <style>
    .collapse {
      cursor: pointer
    }
  </style>
  <style>
    b {
      font-weight: 400 !important
    }

    .dash_casino h2 {
      display: block;
      padding-left: 10px;
      text-align: left
    }

    .listing_screen h2 {
      background: #0000
    }

    .live-casino-block {
      margin-right: 0;
      width: 100%;
      height: 106px
    }

    .live-casino-img {
      width: 100% !important;
      height: 100px
    }

    .live-casino-title {
      font-size: 9px !important;
      border-radius: 0
    }

    .coupon-card {
      margin-bottom: 16px;
      border-radius: 0 0 2px 2px
    }

    .table-bordered {
      border: 1px solid #dee2e6
    }

    .coupon-table {
      margin-bottom: 0
    }

    .text-dark {
      color: #343a40 !important
    }

    .coupon-table tr td:first-child {
      padding-left: 15px;
      vertical-align: middle;
      padding-right: 15px
    }

    .coupon-table tr td {
      padding: 0;
      vertical-align: middle;
      font-size: 14px;
      word-wrap: break-word
    }

    .horse-time-detail {
      display: flex;
      flex-wrap: wrap;
      padding: 5px 5px 0
    }

    .horse-time-detail a {
      display: flex
    }

    .horse-time-detail span {
      font-size: 12px;
      background: #092844;
      color: #fff;
      padding: 5px 10px;
      border-radius: 4px;
      margin-right: 5px;
      margin-bottom: 5px;
      cursor: pointer;
      position: relative;
      -webkit-border-radius: 4px;
      -moz-border-radius: 4px;
      -ms-border-radius: 4px;
      -o-border-radius: 4px
    }

    .horse-time-detail span.active {
      position: relative
    }

    .horse-time-detail span.active:before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      border-right: 10px solid #0000;
      border-top: 10px solid green
    }

    .bet-table.horse-table .row {
      border: 1px solid #ddd
    }

    .bet-table.horse-table .row .col-12 {
      border-left: 1px solid #ddd
    }

    .casinoicons {
      margin-right: 0;
      margin-bottom: 16px;
      box-shadow: none
    }

    .grid-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(110px, 1fr));
      grid-gap: 6px;
      gap: 6px;
      padding: 0 10px
    }

    .img-fluid {
      border-radius: 4px 4px 0 0
    }

    .game-img {
      width: 100%;
      height: 150px
    }

    .games-name {
      background: #1a5684;
      width: 33.33%;
      padding: 6px;
      color: #fff;
      font-size: 12px;
      text-align: center
    }

    .cursor {
      cursor: pointer
    }

    @media (max-width: 767px) {
      .grid-container {
        grid-template-columns: repeat(auto-fill, minmax(84px, 1fr))
      }

      .bet-table.horse-table .row .col-12 {
        border-left: none
      }

      .game-img {
        height: 100px
      }

      .horse-time-detail span {
        background: #092844;
        color: #fff;
        padding: 4px 6px
      }

      .horse-time-detail {
        padding: 0
      }
    }
  </style>
  <style>
     .nav-tabs .nav-item.disabled a.disabled {
      cursor: default
    }
  </style>
  <style>
    .betCounts .matched,
    .betCounts .unmatched {
      min-width: 25px;
      width: auto;
      padding: 0 5px
    }

    .min-max {
      float: right;
      color: #ef4e46;
      font-size: 13px;
      padding: 12px;
      font-weight: 700;
      text-transform: capitalize
    }

    .min-max span {
      margin-right: 5px
    }

    .position-relative {
      position: relative
    }

    .event-title {
      display: flex;
      justify-content: space-between
    }

    .mobile-sec {
      position: relative
    }

    .mobile-sec a.tv {
      top: 9px
    }

    .mobile-sec a.tv i {
      color: #464646
    }

    .no-dt {
      background: #f2f2f2;
      border-bottom: 1px solid #fff;
      text-align: center
    }

    .no-dt p {
      padding: 5px 0;
      margin: 0
    }

    .mobile-sec a.tv {
      position: absolute;
      top: 10px;
      right: 0
    }

    .mobile-sec a.tv i {
      font-weight: bolder;
      color: #fff
    }

    .horse-detail .country-name {
      padding-top: 3px;
      padding-bottom: 3px
    }

    .horse-detail .country-name label {
      display: flex;
      flex-wrap: wrap;
      align-items: flex-start;
      font-size: var(--font-body)
    }

    .horse-detail .country-name label img {
      height: 25px;
      margin-right: 5px;
      border-radius: 2px
    }

    .horse-detail .country-name label div:last-child {
      width: calc(100% - 50px);
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between
    }

    .horse-detail .country-name label div:last-child>span:first-child {
      font-weight: 700;
      float: left;
      width: 100%
    }

    .horse-detail .country-name label .jockey-detail {
      font-size: 14px;
      margin-top: 0;
      flex-wrap: wrap;
      max-width: calc(100% - 70px)
    }

    .horse-time-detail {
      display: flex;
      flex-wrap: wrap;
      padding: 5px 5px 0
    }

    .horse-time-detail a {
      display: flex
    }

    .horse-time-detail span {
      background: var(--theme2-bg);
      color: var(--secondary-color);
      padding: 5px 10px;
      border-radius: 4px;
      margin-right: 5px;
      margin-bottom: 5px;
      cursor: pointer;
      position: relative;
      -webkit-border-radius: 4px;
      -moz-border-radius: 4px;
      -ms-border-radius: 4px;
      -o-border-radius: 4px
    }

    .horse-time-detail span.active {
      position: relative
    }

    .horse-time-detail span.active:before {
      content: "";
      position: absolute;
      left: 0;
      top: 0;
      border-right: 10px solid #0000;
      border-top: 10px solid green
    }

    .horse-detail .suspended:after {
      content: attr(data-title);
      font-size: 16px;
      color: red;
      font-family: Arial, Verdana, Helvetica, sans-serif;
      width: 60%
    }

    .horse-detail .horse-attr {
      background: #ebe7e7;
      border: 1px solid #ccc;
      padding: 1px;
      font-size: 12px;
      margin-left: 2px;
      border-radius: 4px;
      color: #333;
      margin-bottom: 1px;
      font-weight: 400
    }

    .horse-detail .table-row .box-1 {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      align-items: center;
      flex-direction: column
    }

    .horse-detail .custom-checkbox .custom-control-label:before {
      border-radius: .25rem;
      background: #ddd
    }

    .horse-detail .Lay_oddsbox,
    .horse-detail .back_oddsbox {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 100%;
      flex-direction: column
    }

    .nav-item {
      width: 33.33% !important
    }

    @media (min-width: 767px) {
      .d-none-desktop {
        display: none
      }
    }

    @media (max-width: 767px) {
      .horse-detail .country-name label .jockey-detail {
        font-size: 14px;
        margin-top: 0;
        max-width: 100%
      }

      .horse-detail .horse-attr {
        font-size: 10px
      }

      .horse-detail.d-none-desktop {
        display: inline-flex;
        margin-bottom: 2px
      }

      .d-none-mobile {
        display: none
      }

      .horse-detail .country-name label div:last-child>span:first-child {
        margin-bottom: 1px
      }
    }
  </style>
  <style>
    input::-webkit-inner-spin-button,
    input::-webkit-outer-spin-button {
      -webkit-appearance: none;
      margin: 0
    }

    input[type=number] {
      -moz-appearance: textfield
    }

    #overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #000000d9;
      background-color: #00000080;
      z-index: 2;
      color: #807e7e
    }

    .bet-slip-container {
      position: relative
    }

    .bet-input.lay-border:before {
      background-color: #f994ba;
      background-image: linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(var(--bg-table-header), var(--bg-table-header))
    }

    @media (max-width: 767px) {

      button,
      input {
        height: 28px !important;
        line-height: normal !important
      }
    }
  </style>
  <style>
    .scorecard-row .row5 .col-6:last-child {
      text-align: right
    }

    .bold {
      font-weight: 400
    }

    body {
      display: flex;
      justify-content: center
    }

    .widgets {
      width: 100%
    }

    .sr-widget {
      border: 1px solid #0000001f;
      margin-bottom: 24px
    }

    .sr-widget-title {
      font-weight: 700;
      padding-bottom: 4px
    }

    .ball-runs {
      display: inline-block;
      height: 25px;
      width: 25px;
      line-height: 25px;
      align-items: center;
      text-align: center;
      border-radius: 100px;
      padding: 0
    }

    .ball123 {
      background-color: #48a23c
    }

    .ball0 {
      background-color: #999
    }

    .ball45 {
      background-color: #66b2ff
    }

    .ballNo {
      background-color: #c2ad7b
    }

    .ballw {
      background-color: #c9362b
    }

    .ball6 {
      background-color: #883997
    }

    .ball {
      background-color: #087f23
    }

    .team-score {
      display: flex;
      align-items: center;
      justify-content: flex-start
    }

    .required-run {
      color: #c8bfbf
    }

    @media (max-width: 767px) {
      .ball-runs {
        height: 17px;
        width: 17px;
        line-height: 17px
      }
    }

    .OverBox {
      display: flex;
      align-items: center;
      grid-gap: 6px;
      gap: 6px
    }
  </style>
  <style>
    .casino-result-content:before {
      display: none
    }

    .casino-result-content .casino-result-content-item {
      border-right: 1px solid #5c5c5c
    }

    .casino-result-content .casino-result-content-item:last-child {
      border: none
    }

    .casino-result-cards h4 {
      display: inline
    }

    .winner-icon {
      top: 40px
    }

    @media (max-width: 767px) {
      .winner-icon {
        top: 30px
      }

      .casino-result-content .casino-result-content-item:last-child,
      .casino-result-content-item {
        margin-bottom: 5px;
        width: 100%;
        padding: 5px;
        border: 1px solid #5c5c5c
      }

      .casino-result-content {
        justify-content: start
      }
    }
  </style>
  <style>
    .bets-section div {
      font-size: 12px;
      font-weight: 600
    }

    .bets-section input {
      height: 28px;
      background: #fff;
      border-radius: 0
    }

    .stakes .btn-group button {
      text-align: center;
      min-width: 16.5%;
      display: flex;
      width: 100%;
      margin: 3px 1px;
      padding: 2px;
      justify-content: center
    }

    .stakes .btn-group {
      width: 98%
    }

    .casino-place-bet {
      width: 100%;
      margin-bottom: 6px
    }

    .casino-place-bet-title {
      padding: 8px;
      text-transform: uppercase;
      font-weight: 700;
      background-color: #464646;
      color: #fff;
      font-size: 15px
    }

    .casino-place-bet-title .casino-min-max {
      text-transform: capitalize
    }

    .casino-place-bet-header {
      padding: 8px;
      background-color: #ccc;
      font-size: 12px;
      font-weight: 700;
      text-align: center;
      margin: 0
    }

    .casino-place-bet-box,
    .casino-place-bet-header {
      display: flex;
      display: -webkit-flex;
      justify-content: space-between;
      color: #303030
    }

    .casino-place-bet-box {
      background-color: #f9f9f9;
      padding: 6px;
      flex-wrap: wrap
    }

    .casino-place-bet-info {
      display: flex;
      display: -webkit-flex;
      width: 100%;
      justify-content: space-between;
      align-items: center
    }

    .odds-box {
      position: relative;
      height: 40px;
      width: 80px;
      border: 1px solid #3c444b;
      border-radius: 4px;
      padding: 0;
      background-color: #3c444b
    }

    .odds-box input {
      color: #ced4da
    }

    input.form-control:disabled {
      cursor: not-allowed;
      background-color: initial
    }

    .odds-box .arrow-up {
      top: 9px;
      transform: scaleY(-1)
    }

    .odds-box .arrow-down,
    .odds-box .arrow-up {
      position: absolute;
      right: 8px;
      width: auto;
      height: auto
    }

    .odds-box .arrow-down {
      bottom: 9px
    }

    .casino-place-bet-info .bet-input {
      width: 80px
    }

    .bet-input.back-border,
    .bet-input.lay-border {
      border-left: 0
    }

    .bet-input {
      margin-top: 0;
      margin-left: 0;
      width: calc(48% - 8px);
      display: inline-block;
      vertical-align: top;
      position: relative;
      z-index: 0;
      overflow: hidden;
      height: 36px
    }

    .back-border {
      border-left: 5px solid #72bbef
    }

    .bet-input .form-control {
      color: #aaafb5;
      height: 36px;
      border: 0;
      background-color: initial
    }

    .bet-input.back-border:before {
      background-color: #72bbef;
      background-image: linear-gradient(#72bbef, #72bbef), linear-gradient(#72bbef, #72bbef), linear-gradient(#72bbef, #72bbef), linear-gradient(#3c444b, #3c444b)
    }

    .bet-input:before {
      content: "";
      position: absolute;
      z-index: -2;
      left: -50%;
      top: -50%;
      width: 200%;
      height: 200%;
      background-repeat: no-repeat;
      background-size: 50% 50%, 50% 50%;
      background-position: 0 0, 100% 0, 100% 100%, 0 100%;
      animation-name: rotateborder;
      animation-duration: 4s;
      animation-timing-function: linear;
      animation-iteration-count: infinite;
      -webkit-animation-name: rotateborder;
      -webkit-animation-duration: 4s;
      -webkit-animation-timing-function: linear;
      -webkit-animation-iteration-count: infinite;
      -moz-animation-name: rotateborder;
      -moz-animation-duration: 4s;
      -moz-animation-timing-function: linear;
      -moz-animation-iteration-count: infinite
    }

    .bet-input:after {
      content: "";
      position: absolute;
      z-index: -1;
      left: 1px;
      top: 1px;
      width: calc(100% - 2px);
      height: calc(100% - 2px);
      background: #23292e;
      border-radius: 0;
      -webkit-transform: translateZ(0)
    }

    .casino-place-bet-button-container {
      display: flex;
      display: -webkit-flex;
      width: 100%;
      flex-wrap: wrap;
      margin-top: 6px
    }

    .casino-place-bet-button-container .btn {
      margin-right: 1%;
      margin-bottom: 1%;
      width: 24%;
      padding: 0
    }

    [type=button]:not(:disabled),
    [type=reset]:not(:disabled),
    [type=submit]:not(:disabled),
    button:not(:disabled) {
      cursor: pointer
    }

    .btn-bet {
      height: 34px;
      background-color: #ccc;
      border-color: #0000;
      color: #303030 !important;
      font-size: 14px
    }

    .btn {
      box-shadow: none !important;
      height: auto;
      color: #fff;
      border-radius: 4px
    }

    .casino-place-bet-action-buttons {
      display: flex;
      display: -webkit-flex;
      justify-content: space-between;
      flex-wrap: wrap;
      width: 100%
    }

    .casino-place-bet-action-buttons .btn {
      height: 40px;
      width: 112px
    }

    .btn-reset {
      background-color: #fc4242;
      border-color: #fc4242
    }

    .bet-input.lay-border:before {
      background-color: #f994ba;
      background-image: linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(#f994ba, #f994ba), linear-gradient(var(--bg-table-header), var(--bg-table-header))
    }

    button.btn.betplace-btn {
      height: 25px;
      line-height: 25px;
      min-height: 25px;
      padding: 0 !important
    }

    @media (max-width: 767px) {
      .stakes .btn-group {
        min-width: 100%;
        display: block
      }

      .stakes .btn-group button {
        width: 30%;
        margin: 5px
      }

      .bets-section h2,
      .cancel-btn {
        display: none
      }
    }
  </style>
  <style>
    .roulette-block {
      position: absolute;
      bottom: 0;
      transform: translate(-50%);
      z-index: 10;
      left: 50%
    }

    @media (max-width:1300px) {
      div.roulette-result {
        grid-template-columns: none;
        -webkit-column-gap: 10px;
        grid-column-gap: 10px;
        column-gap: 10px;
        grid-row-gap: 10px;
        row-gap: 10px
      }

      div.roulette-result__column {
        background-color: #24387e;
        color: #9ea7c7;
        padding: 15px 30px;
        min-height: auto;
        display: block
      }

      div.roulette-result__column p {
        color: #9ea7c7
      }

      div.roulette-result__column p span {
        color: #fff
      }

      div.roulette-result__time {
        margin-bottom: 15px;
        text-align: start
      }

      div.roulette-result__time .date {
        margin-right: 10px
      }

      div.roulette-result__wraper {
        display: flex;
        -webkit-column-gap: 15px;
        grid-column-gap: 15px;
        column-gap: 15px;
        grid-row-gap: 10px;
        row-gap: 10px;
        flex-direction: column
      }

      div.roulette-result__wraper-cards {
        margin: 30px 0;
        height: unset;
        display: flex;
        justify-content: center;
        align-items: center
      }

      div.roulette-result__winner {
        height: unset;
        margin: 30px 0
      }

      div.roulette-result img {
        width: 27px;
        height: 40px
      }

      div.roulette-result img:not(:last-child) {
        margin-right: 5px
      }

      div.roulette-result img:first-child {
        margin-left: 0
      }
    }

    .roulette-result {
      display: grid;
      grid-template-columns: 1fr
    }

    .roulette-result__column {
      background-color: #24387e;
      color: #9ea7c7;
      padding: 15px 30px;
      min-height: 200px;
      display: grid;
      grid-template-columns: 1fr 1fr;
      grid-template-rows: 10px
    }

    .roulette-result__column p {
      color: #9ea7c7
    }

    .roulette-result__column p span {
      color: #fff
    }

    .roulette-result__time {
      text-align: end
    }

    .roulette-result__time .date {
      margin-right: 10px
    }

    .roulette-result__wraper {
      display: flex;
      -webkit-column-gap: 15px;
      grid-column-gap: 15px;
      column-gap: 15px
    }

    .roulette-result__wraper-cards {
      height: 90%;
      display: flex;
      justify-content: center;
      align-items: center;
      grid-area: 2/1/3/3;
      -webkit-column-gap: 10px;
      grid-column-gap: 10px;
      column-gap: 10px;
      font-size: 18px
    }

    .roulette-result__wraper-name {
      margin-right: 10px;
      white-space: nowrap;
      font-weight: 600
    }

    .roulette-result__wraper-chip {
      font-family: Source Sans Pro, sans-serif;
      font-weight: 600;
      font-size: 22px;
      line-height: 24px;
      border-radius: 5px;
      color: #fff;
      width: 35px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 2px 3px 5px #121e491c;
      background: #fff;
      border: 1.13324px solid #fff
    }

    .roulette-result__winner {
      display: flex;
      height: 90%;
      justify-content: center;
      align-items: center
    }

    .roulette-result__winner-name {
      margin-left: 10px;
      white-space: nowrap;
      font-weight: 600
    }

    .roulette-result img {
      width: 27px;
      height: 40px
    }

    .roulette-result img:not(:last-child) {
      margin-right: 5px
    }

    .roulette-result img:first-child {
      margin-left: 0
    }

    .last-results__body-button.roulette {
      border-radius: 5px;
      color: #fff
    }

    .last-results__body-button.roulette:active {
      background-color: #ff7a40 !important;
      color: #fff
    }

    @media (max-width:1600px) {
      div.roulette-table__body-cell {
        font-size: 33px;
        padding: 1px
      }

      div.roulette-table__body-cell.zero-cell {
        height: 135px;
        width: 70px
      }

      div.roulette-table__body sup {
        font-size: 16px
      }

      div.roulette-table__body-td-inner-wrapper:first-child span {
        font-size: 33px
      }

      div.roulette-table__body .rectangle-icon-wrapper {
        padding: 6px 5px;
        min-height: 54px;
        display: flex;
        justify-content: center;
        align-items: center
      }

      div.roulette-table__body .roulette-table__body-color-rectangle {
        height: 25px
      }
    }

    @media (max-width:1300px) {
      div.roulette-table__body {
        padding: 10px 5px 5px
      }
    }

    @media (max-width:851px) {
      div.roulette-table__body {
        flex-direction: column
      }

      div.roulette-table__body-tr.zero-column {
        display: flex;
        justify-content: center
      }

      div.roulette-table__body-tr.zero-column .zero-cell {
        clip-path: polygon(50% 1%, 100% 40%, 100% 100%, 0 99%, 0 40%);
        width: 140px;
        height: 70px
      }

      div.roulette-table__body-tr.zero-column .zero-cell span {
        padding: 5px 0 0
      }

      div.roulette-table__body .column-nums {
        max-width: 100%
      }

      div.roulette-table__body .column-nums,
      div.roulette-table__body .column-nums .multiple-bid-wrapper {
        display: flex;
        flex-direction: row-reverse
      }

      div.roulette-table__body .roulette-table__body-td.num-cell-wrapper {
        width: 70%;
        display: flex;
        flex-direction: row-reverse
      }

      div.roulette-table__body .roulette-table__body-td.multiple-bid-wrapper {
        width: 30%
      }

      div.roulette-table__body .roulette-table__body-td-inner-wrapper.num-cell-inner-wrapper {
        display: flex;
        flex-direction: column;
        width: 33.33333%
      }

      div.roulette-table__body-cell.num-cell {
        width: 100%
      }

      div.roulette-table__body-td.multiple-bid-wrapper div.roulette-table__body-td-inner-wrapper {
        width: 50%
      }

      div.roulette-table__body-td-inner-wrapper:first-child .multiple-cell {
        height: 100%
      }

      div.roulette-table__body-td-inner-wrapper:last-child .multiple-cell {
        width: 100%;
        height: 50%;
        padding: 2px;
        white-space: nowrap
      }

      div.roulette-table__body-td-inner-wrapper:last-child .roulette-table__body-color-rectangle {
        height: auto;
        width: 57px;
        transform: rotate(90deg)
      }

      div.roulette-table__body-td-inner-wrapper .multiple-cell {
        font-size: 15px
      }

      div.roulette-table__body .rectangle-icon-wrapper {
        width: 35px
      }

      div.roulette-table__body .roulette-table__body-td.multiple-bid-wrapper.wrapper-2to1 {
        display: flex;
        width: 70%;
        margin-left: auto;
        flex-direction: row-reverse
      }

      div.roulette-table__body .roulette-table__body-td.multiple-bid-wrapper.wrapper-2to1 .multiple-cell {
        width: 33.33333%
      }
    }

    .test1 {
      display: none
    }

    .roulette-table__body-cell {
      font-weight: 400;
      font-family: Source Sans Pro, sans-serif
    }

    .roulette-table__body {
      width: 100%;
      max-width: 1180px;
      padding-top: 50px;
      display: flex;
      margin: 0 auto
    }

    .roulette-table__body-cell {
      color: #fff;
      border: 1px solid #fff;
      font-size: 44px;
      padding: 2px 5px;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      position: relative;
      text-align: center
    }

    .roulette-table__body-cell.zero-cell {
      background: #32cda8;
      clip-path: polygon(40% 0, 100% 0, 100% 100%, 40% 100%, 1% 50%);
      height: 184px;
      width: 93px
    }

    .roulette-table__body-cell.zero-cell span {
      padding-left: 5px
    }

    .roulette-table__body-tr.column-nums {
      width: 100%;
      max-width: 334px
    }

    .roulette-table__body-cell.num-cell {
      width: 25%
    }

    .roulette-table__body-cell.black-num {
      background: #000
    }

    .roulette-table__body-cell.red-num {
      background: #dc3a24
    }

    .roulette-table__body-cell.multiple-cell {
      background: #0009
    }

    .roulette-table__body-cell.black-num:active,
    .roulette-table__body-cell.multiple-cell:active,
    .roulette-table__body-cell.red-num:active,
    .roulette-table__body-cell.zero-cell:active {
      background-color: #ff7a40
    }

    .roulette-table__body-cell.block {
      pointer-events: none
    }

    .roulette-table__body-cell.block:hover {
      cursor: unset
    }

    .roulette-table__body .chip-wrapper {
      position: absolute;
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 3
    }

    .roulette-table__body sup {
      font-size: 21px
    }

    .roulette-table__body-td-inner-wrapper.num-cell-inner-wrapper {
      display: flex
    }

    .roulette-table__body .inner-wrapper-1-18-even,
    .roulette-table__body .inner-wrapper-odd-19-36,
    .roulette-table__body .inner-wrapper-red-black {
      display: flex;
      flex-wrap: wrap
    }

    .roulette-table__body .inner-wrapper-1-18-even .multiple-cell,
    .roulette-table__body .inner-wrapper-odd-19-36 .multiple-cell,
    .roulette-table__body .inner-wrapper-red-black .multiple-cell {
      width: 50%
    }

    .roulette-table__body-color-rectangle {
      height: 31px
    }

    .roulette-table__body .rectangle-icon-wrapper {
      padding: 14px 5px
    }

    .roulette-table__body-tr.column-2to1 {
      flex-shrink: 0
    }

    .Red {
      background-color: #dc3a24
    }

    .Black {
      background-color: #000
    }

    .Green {
      background-color: #32cda8
    }

    @media (max-width:767px) {

      .roulette-table__body .inner-wrapper-1-18-even .multiple-cell,
      .roulette-table__body .inner-wrapper-odd-19-36 .multiple-cell,
      .roulette-table__body .inner-wrapper-red-black .multiple-cell {
        width: 100%
      }
    }
  </style>
</head>