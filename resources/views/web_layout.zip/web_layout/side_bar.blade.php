<app-sidebar>
    <nav class="nav-menu">
        <ul>
            <li>
                <a data-toggle="collapse" href="javascript:void(0)" role="button" aria-expanded="true" aria-controls="SubsideMenu1" class="active"><span _ngcontent-wcx-c73="">Casino</span><b _ngcontent-wcx-c73="" class="iconsmenu"><i _ngcontent-wcx-c73="" class="fa fa-chevron-down"></i></b></a>
                <div id="SubsideMenu1" class="collapse show">
                    <ul><!----><!----></ul>
                    <ul><!----><!----></ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/12959"><span> Casino War
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9690"><span> Race 20-20
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9687"><span> Trio </span></a>
                        </li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9687"><span> The Trap
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9687"><span> Bollywood Casino
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9686"><span> Queen
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9280"><span> Teenpatti Test
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9686"><span> Baccarat
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9280"><span> Poker 2020
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9280"><span> Mulfis Teenpatti
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9304"><span> 2 Cards
                                    Teenpatti </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9304"><span> Casino Meter
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9315"><span> Sicbo
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9315"><span> 1 Day Teenpatti
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9315"><span> 1 Day Poker
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9316"><span> Roulette
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9314"><span> 1 Day Dragon
                                    Tiger </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9316"><span> Amar Akbar
                                    Anthony </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9316"><span> Andar Bahar
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9316"><span> 7 Up &amp; Down
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9316"><span> Worli Matka
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9655"><span> Teenpatti T20
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9655"><span> 32 Card Casino
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9655"><span> Hi-Low
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9324"><span> Teenpatti
                                    One-Day (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9324"><span> Teenpatti T20
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9324"><span> 7 up &amp; down
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9665"><span> 32 Cards
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9665"><span> Poker (Virtual)
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9665"><span> Six player poker
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9665"><span> Andar Bahar
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9682"><span> Matka (Virtual)
                                </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9682"><span> Roulette
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9682"><span> Dragon Tiger
                                    (Virtual) </span></a></li><!---->
                    </ul>
                    <ul><!---->
                        <li><a href="https://crickekbuz.art/slot/game/lounch/9682"><span> Amar Akbar
                                    Anthony (Virtual) </span></a></li><!---->
                    </ul><!---->
                </div>
            </li><!---->
        </ul>
    </nav><!---->
</app-sidebar>